"""agent-skill-mcp Python SDK。

为业务代码提供访问 Agent Skill & MCP Platform 的统一接口，
支持定义 agent 配置（指定 skill 和 mcp 名称）并自动从平台拉取配置。

快速上手
--------

异步方式::

    import asyncio
    from agent_skill_mcp import PlatformClient, AgentBuilder

    async def main():
        client = PlatformClient("http://127.0.0.1:8000", "your-api-key")
        builder = AgentBuilder(client)
        config = await builder.build("my-agent")
        print(config.name, [s.name for s in config.skills])

    asyncio.run(main())

同步方式::

    from agent_skill_mcp import PlatformClient

    client = PlatformClient("http://127.0.0.1:8000", "your-api-key")
    config = client.get_sync("my-agent")
    print(config["name"])
"""

from .agent import AgentBuilder, AgentConfig
from .adapter import MCPConfigAdapter
from .model import ModelConfigAdapter
from .client import PlatformClient
from .exceptions import (
    AuthenticationError,
    ConnectionError,
    NotFoundError,
    PlatformError,
)
from .mcp import MCPManager
from .skill import Skill, SkillLoader

__version__ = "0.1.0"

__all__ = [
    # 核心客户端
    "PlatformClient",
    # 构建器与配置
    "AgentBuilder",
    "AgentConfig",
    # 技能
    "Skill",
    "SkillLoader",
    # MCP
    "MCPManager",
    "MCPConfigAdapter",
    # 模型
    "ModelConfigAdapter",
    # 异常
    "PlatformError",
    "AuthenticationError",
    "NotFoundError",
    "ConnectionError",
    # 版本
    "__version__",
]
