"""MCP 配置适配器。

将平台返回的 MCP 模板配置转换为常见 Agent 框架（如
``langchain-mcp-adapters`` 的 ``MultiServerMCPClient``）所需的格式，
并自动从本地环境变量注入真实认证信息（认证分离方案）。

核心职责：
1. 接收平台已返回的 MCP 配置（或按名称逐个拉取）
2. 根据 ``transport_type`` 和 ``auth_config`` 补充认证
3. 输出框架可直接使用的配置字典
"""

from __future__ import annotations

import os
from typing import Any

from .client import PlatformClient


class MCPConfigAdapter:
    """MCP 配置适配器。

    将平台存储的 MCP 模板配置转换为业务框架可用格式，
    并自动补充业务服务自己的认证信息。

    Usage:
        # 方式1: 已有 agent_config，直接复用（推荐，不重复请求平台）
        adapter = MCPConfigAdapter()
        mcp_config = await adapter.build_from_mcps(agent_config.mcps)

        # 方式2: 只有名称列表，需逐个请求平台
        adapter = MCPConfigAdapter(client)
        mcp_config = await adapter.build_mcp_config(["tavily-search", "gildata_datamap-tools"])
    """

    def __init__(self, client: PlatformClient | None = None) -> None:
        self.client = client

    async def build_from_mcps(
        self, mcps: list[dict[str, Any]]
    ) -> dict[str, dict[str, Any]]:
        """直接基于 agent_config 中已有的 MCP 配置列表构建配置。

        避免重复请求平台，只补充本地认证信息（认证分离方案）。

        Parameters
        ----------
        mcps:
            AgentBuilder 已拉取的 MCP 配置列表
            （含 server_url/transport_type/auth_type/auth_config）。

        Returns
        -------
        dict
            符合 MultiServerMCPClient 格式的配置字典。
        """
        config: dict[str, dict[str, Any]] = {}
        for mcp_data in mcps:
            name = mcp_data.get("name", "")
            try:
                server_config = self._convert_from_data(mcp_data)
                if server_config:
                    config[name] = server_config
                    print(f"  [OK] 已加载 MCP: {name}")
            except Exception as e:
                print(f"  [SKIP] 跳过 MCP '{name}': {e}")
        return config

    @staticmethod
    async def load_tools(
        config: dict[str, dict[str, Any]] | None = None,
    ) -> list:
        """根据已构建的 MCP 配置连接各 Server 并加载可用工具。

        依赖 ``langchain-mcp-adapters``，请通过
        ``pip install agent-skill-mcp[langchain]`` 安装。

        Parameters
        ----------
        config:
            ``build_from_mcps`` / ``build_mcp_config`` 返回的配置字典。
            为 None 或空字典时返回空列表。

        Returns
        -------
        list
            已加载的工具列表（``langchain_core.tools.BaseTool``）。
        """
        if not config:
            return []

        from langchain_mcp_adapters.client import MultiServerMCPClient

        # langchain-mcp-adapters 0.1.x 不支持 async with，需直接实例化
        mcp_client = MultiServerMCPClient(config)
        return await mcp_client.get_tools()

    async def build_mcp_config(
        self, mcp_names: list[str] | None = None
    ) -> dict[str, dict[str, Any]]:
        """构建 MCP Server 配置（会逐个请求平台拉取）。

        Parameters
        ----------
        mcp_names:
            要加载的 MCP 名称列表。为 None 时加载平台所有已激活的 MCP。

        Returns
        -------
        dict
            符合 MultiServerMCPClient 格式的配置字典。
        """
        if self.client is None:
            raise ValueError("使用 build_mcp_config 需要传入 PlatformClient")

        if mcp_names is None:
            mcp_names = await self._get_all_mcp_names()

        config: dict[str, dict[str, Any]] = {}
        for name in mcp_names:
            try:
                server_config = await self._convert_single(name)
                if server_config:
                    config[name] = server_config
                    print(f"  [OK] 已加载 MCP: {name}")
            except Exception as e:
                print(f"  [SKIP] 跳过 MCP '{name}': {e}")

        return config

    async def _get_all_mcp_names(self) -> list[str]:
        """获取平台所有已激活的 MCP 名称。"""
        import httpx

        async with httpx.AsyncClient(
            base_url=self.client.base_url,
            headers={"X-API-Key": self.client.api_key},
            timeout=30.0,
        ) as http_client:
            response = await http_client.get("/api/v1/mcps")
            response.raise_for_status()
            data = response.json()
            return [m["name"] for m in data if m.get("is_active", True)]

    def _convert_from_data(self, mcp_data: dict[str, Any]) -> dict[str, Any] | None:
        """将单个 MCP 配置数据（已从平台拉取）转换为框架格式。

        核心逻辑：根据 transport_type 和 auth_config 补充认证信息。
        不再请求平台，直接使用已有数据。
        """
        name = mcp_data.get("name", "")
        transport = mcp_data.get("transport_type", "stdio")
        server_url = mcp_data.get("server_url", "")
        auth_type = mcp_data.get("auth_type", "none")
        auth_config = mcp_data.get("auth_config", {}) or {}

        if transport == "stdio":
            return self._convert_stdio(mcp_data, server_url, auth_type, auth_config)
        elif transport in ("sse", "http", "streamable_http"):
            return self._convert_http(mcp_data, server_url, transport, auth_type, auth_config)
        else:
            print(f"  [WARN] 未知的 transport_type '{transport}' for {name}")
            return None

    async def _convert_single(self, name: str) -> dict[str, Any] | None:
        """将单个平台 MCP 配置转换为框架格式（会请求平台拉取单个 MCP）。

        核心逻辑：根据 transport_type 和 auth_config 补充认证信息。
        """
        mcp_data = await self.client.get_mcp(name)
        return self._convert_from_data(mcp_data)

    def _convert_stdio(
        self,
        mcp_data: dict,
        server_url: str,
        auth_type: str,
        auth_config: dict,
    ) -> dict[str, Any]:
        """转换 stdio 类型 MCP（如 npx 启动的本地服务）。

        平台存储模板：
          server_url: "npx -y tavily-mcp"
          auth_config: {"auth_location": "env", "param_name": "TAVILY_API_KEY"}

        业务服务补充：
          从环境变量读取真实 API Key
        """
        # 解析命令
        parts = server_url.split()
        command = parts[0] if parts else "npx"
        args = parts[1:] if len(parts) > 1 else []

        # 构建环境变量
        env: dict[str, str] = {}

        if auth_type == "api_key" and auth_config.get("auth_location") == "env":
            param_name = auth_config.get("param_name", "")
            if param_name:
                # 从业务服务的环境变量读取真实值
                real_value = os.getenv(param_name)
                if real_value:
                    env[param_name] = real_value
                    print(f"       已注入认证: {param_name} (from env)")
                else:
                    print(f"       [WARN] 环境变量 {param_name} 未设置")

        # 合并 env_template（平台的非敏感默认值）
        env_template = auth_config.get("env_template", {})
        for k, v in env_template.items():
            if k not in env:
                env[k] = v

        return {
            "transport": "stdio",
            "command": command,
            "args": args,
            "env": env if env else None,
        }

    def _convert_http(
        self,
        mcp_data: dict,
        server_url: str,
        transport: str,
        auth_type: str,
        auth_config: dict,
    ) -> dict[str, Any]:
        """转换 HTTP/SSE 类型 MCP（如 gildata 远程服务）。

        平台存储模板：
          server_url: "https://api.gildata.com/mcp-servers/xxx"
          auth_config: {"auth_location": "url_query", "param_name": "token"}

        业务服务补充：
          从环境变量读取真实 token，拼接到 URL
        """
        final_url = server_url

        # 补充 URL query 参数认证
        if auth_type == "api_key" and auth_config.get("auth_location") == "url_query":
            param_name = auth_config.get("param_name", "")
            if param_name:
                # 环境变量名规则: 转大写，平台 MCP 名 -> ENV
                # 优先用 auth_config 指定的 token 环境变量
                token_value = os.getenv(param_name.upper()) or os.getenv(param_name)

                # 兜底：根据 MCP 名称推断环境变量
                if not token_value:
                    mcp_name = mcp_data.get("name", "")
                    if mcp_name.startswith("gildata"):
                        token_value = os.getenv("GILDATA_TOKEN")

                if token_value:
                    separator = "&" if "?" in final_url else "?"
                    final_url = f"{final_url}{separator}{param_name}={token_value}"
                    print(f"       已注入认证: {param_name} (url_query)")
                else:
                    print(f"       [WARN] 认证参数 {param_name} 未找到对应环境变量")

        # 构建 headers
        headers = auth_config.get("headers", {})
        if not headers:
            headers = {
                "Accept": "application/json, text/event-stream",
                "Content-Type": "application/json",
            }

        # MultiServerMCPClient 使用的 transport 名称
        # streamable_http -> http, sse -> sse
        mcp_transport = "http" if transport in ("http", "streamable_http") else "sse"

        return {
            "transport": mcp_transport,
            "url": final_url,
            "headers": headers,
        }
