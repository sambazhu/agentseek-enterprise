"""Agent 配置构建模块。

提供 ``AgentConfig`` 配置容器和 ``AgentBuilder`` 构建器。
``AgentBuilder`` 从平台拉取 agent 配置并自动解析其关联的 skills 和 mcps，
构建完成后可直接传递给 LangChain / CrewAI 等下游框架。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .client import PlatformClient
from .mcp import MCPManager
from .skill import Skill, SkillLoader


@dataclass
class AgentConfig:
    """已解析的 agent 配置容器。

    由 ``AgentBuilder.build()`` 构建完成后产出，包含 agent 的全部信息：
    关联的技能列表、MCP Server 列表以及模型配置。

    Attributes
    ----------
    name:
        Agent 名称。
    skills:
        已加载的 ``Skill`` 对象列表。
    mcps:
        MCP Server 配置字典列表。
    model_config:
        模型配置（如 model 名称、temperature 等）。
    id:
        Agent 在平台中的唯一 ID。
    version:
        Agent 版本号。
    description:
        Agent 描述。
    """

    name: str
    skills: list[Skill] = field(default_factory=list)
    mcps: list[dict[str, Any]] = field(default_factory=list)
    model_config: dict[str, Any] = field(default_factory=dict)
    id: str = ""
    version: str = ""
    description: str = ""

    def get_skill_body(self, skill_name: str) -> str | None:
        """按名称获取某个 skill 的完整 body 正文。

        供业务代码或 Tool 函数调用，实现 LLM 对 skill body 的按需加载。

        Parameters
        ----------
        skill_name:
            技能名称。

        Returns
        -------
        str | None
            技能的 body 正文；未找到时返回 None。
        """
        for s in self.skills:
            if s.name == skill_name:
                return s.body
        return None

    def export_skills_to_dir(
        self,
        output_dir: str,
        *,
        include_attachments: bool = False,
        overwrite: bool = False,
        client: PlatformClient | None = None,
    ) -> list[str]:
        """将所有 skill 的 body 导出到本地 Markdown 文件，可选导出附件。

        适用于 DeepAgent 等带文件系统工具的 Agent：LLM 可通过
        ``read_file`` 工具按需读取 skill 详情，而非全部塞入 system_prompt。

        导出文件命名为 ``{output_dir}/{skill_name}.md``。
        当 ``include_attachments=True`` 且传入 ``client`` 时，每个 skill 的附件
        会下载到 ``{output_dir}/{skill_name}/`` 子目录下（与 .md 同名目录）。

        Parameters
        ----------
        output_dir:
            输出目录路径，不存在时会自动创建。
        include_attachments:
            是否同时下载附件，默认 False。设为 True 需同时传入 client。
        overwrite:
            是否覆盖已存在的文件，默认 False。内容一致时跳过。
        client:
            平台客户端实例，用于下载附件。

        Returns
        -------
        list[str]
            已写入的文件路径列表。
        """
        import os
        from pathlib import Path

        os.makedirs(output_dir, exist_ok=True)
        written: list[str] = []
        for s in self.skills:
            if not s.body:
                continue
            file_path = os.path.join(output_dir, f"{s.name}.md")
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(s.body)
            written.append(file_path)

            # 同步下载附件到 {skill_name}/ 子目录
            if include_attachments and client and s.id:
                att_dir = os.path.join(output_dir, s.name)
                os.makedirs(att_dir, exist_ok=True)
                att_files = client.download_skill_attachments_sync(
                    s.id, att_dir, overwrite=overwrite, prefer_zip=True
                )
                written.extend(att_files)

        return written

    def build_system_prompt(self, base_prompt: str = "", *, include_skill_body: bool = False) -> str:
        """将关联的 Skills 拼接为完整的 system_prompt。

        默认只拼 skill 的描述（节省 token），LLM 需要完整操作指引时
        可通过文件读取工具按需加载 body 内容。

        Parameters
        ----------
        base_prompt:
            业务自定义的基础提示词，会放在 Skills 之前。
            为空时只输出 Skills 部分。
        include_skill_body:
            是否将 skill 的完整 body 正文拼入 prompt。
            默认 False（仅拼描述，推荐）。设为 True 会显著增加 token 消耗。

        Returns
        -------
        str
            拼接好的 system_prompt。若没有 skills 则直接返回 base_prompt。
        """
        if not self.skills:
            return base_prompt

        skill_sections = "\n".join(
            s.to_prompt_section(include_body=include_skill_body) for s in self.skills
        )

        if base_prompt:
            return (
                f"{base_prompt}\n\n"
                f"# 可用 Skills\n"
                f"以下是你可以使用的专业技能，需要时请读取对应 skill 文件获取详细操作指引：\n\n"
                f"{skill_sections}\n"
            )
        return (
            f"# 可用 Skills\n"
            f"以下是你可以使用的专业技能，需要时请读取对应 skill 文件获取详细操作指引：\n\n"
            f"{skill_sections}\n"
        )


class AgentBuilder:
    """Agent 配置构建器。

    从平台拉取指定 agent 的完整配置，自动解析其关联的 skills 和 mcps，
    并组装为 ``AgentConfig`` 返回。业务代码可直接使用该配置初始化
    LangChain Agent、CrewAI Crew 等。

    Parameters
    ----------
    client:
        已配置好的 ``PlatformClient`` 实例。
    """

    def __init__(self, client: PlatformClient) -> None:
        self.client = client
        self.skill_loader = SkillLoader(client)
        self.mcp_manager = MCPManager(client)

    async def build(self, name: str) -> AgentConfig:
        """构建指定 agent 的完整配置。

        流程：
        1. 从平台获取 agent 配置（含已解析的 skills 和 mcps）。
        2. 将原始 skill 数据转换为 ``Skill`` 对象。
        3. 组装为 ``AgentConfig`` 返回。

        Parameters
        ----------
        name:
            Agent 名称。

        Returns
        -------
        AgentConfig
            已解析的 agent 配置。

        Raises
        ------
        NotFoundError
            指定名称的 agent 不存在时抛出。
        AuthenticationError
            API Key 无效或权限不足时抛出。
        """
        data = await self.client.get_agent_config(name)

        # 将原始 skill 数据转换为 Skill 对象
        skills = [Skill(**skill_data) for skill_data in data.get("skills", [])]

        # 获取 MCP 配置列表（平台已解析好，直接使用）
        mcps = data.get("mcps", [])

        # 模型配置
        model_config = data.get("model_config", {}) or {}

        return AgentConfig(
            id=data.get("id", ""),
            name=data.get("name", name),
            version=data.get("version", ""),
            description=data.get("description", ""),
            skills=skills,
            mcps=mcps,
            model_config=model_config,
        )
