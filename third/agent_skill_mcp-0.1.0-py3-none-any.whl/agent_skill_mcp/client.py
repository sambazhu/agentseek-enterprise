"""平台 HTTP 客户端模块。

提供 PlatformClient，封装与 Agent Skill & MCP Platform 后端的所有交互，
支持异步请求、内存缓存（带 TTL）以及同步便捷方法。
"""

from __future__ import annotations

import time
from typing import Any

import httpx

from .exceptions import (
    AuthenticationError,
    ConnectionError,
    NotFoundError,
    PlatformError,
)

# 默认请求超时时间（秒）
_DEFAULT_TIMEOUT: float = 30.0


class PlatformClient:
    """与平台后端交互的客户端。

    支持异步（``await client.get_agent_config(...)``）和同步
    （``client.get_sync(...)``）两种调用方式。
    内置带 TTL 的内存缓存，避免短时间内重复请求同一资源。

    Parameters
    ----------
    base_url:
        平台后端地址，例如 ``http://127.0.0.1:8000``。
    api_key:
        平台分配的 API Key，将通过 ``X-API-Key`` 请求头发送。
    cache_ttl:
        缓存存活时间（秒），默认 300 秒。设为 0 可禁用缓存。
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        cache_ttl: int = 300,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.cache_ttl = cache_ttl
        # 缓存结构: key -> (写入时间戳, 数据)
        self._cache: dict[str, tuple[float, Any]] = {}
        # 异步 / 同步 httpx 客户端（惰性初始化）
        self._async_client: httpx.AsyncClient | None = None
        self._sync_client: httpx.Client | None = None

    # ------------------------------------------------------------------
    # 内部工具方法
    # ------------------------------------------------------------------

    @property
    def _headers(self) -> dict[str, str]:
        """构造鉴权请求头。"""
        return {"X-API-Key": self.api_key}

    def _cache_get(self, key: str) -> Any | None:
        """从缓存中读取数据，过期则移除。"""
        if self.cache_ttl <= 0:
            return None
        entry = self._cache.get(key)
        if entry is None:
            return None
        timestamp, value = entry
        if time.time() - timestamp < self.cache_ttl:
            return value
        # 已过期，清理
        self._cache.pop(key, None)
        return None

    def _cache_set(self, key: str, value: Any) -> None:
        """写入缓存。"""
        if self.cache_ttl <= 0:
            return
        self._cache[key] = (time.time(), value)

    @staticmethod
    def _make_cache_key(method: str, endpoint: str, params: dict | None) -> str:
        """根据请求方法和路径生成缓存键。"""
        param_str = str(sorted(params.items())) if params else ""
        return f"{method}:{endpoint}:{param_str}"

    def _raise_for_status(self, response: httpx.Response, endpoint: str) -> None:
        """根据 HTTP 状态码抛出对应的异常。"""
        status = response.status_code
        if status in (401, 403):
            raise AuthenticationError(
                "API Key 无效或权限不足，请检查 api_key 配置",
                status_code=status,
            )
        if status == 404:
            raise NotFoundError(
                f"资源未找到: {endpoint}",
                status_code=status,
            )
        if status >= 400:
            # 尝试解析后端返回的错误信息
            detail = ""
            try:
                body = response.json()
                detail = body.get("detail") or body.get("message") or ""
            except Exception:
                detail = response.text[:200]
            msg = f"平台请求失败 (HTTP {status})"
            if detail:
                msg = f"{msg}: {detail}"
            raise PlatformError(msg, status_code=status)

    # ------------------------------------------------------------------
    # 异步请求
    # ------------------------------------------------------------------

    async def _get_async_client(self) -> httpx.AsyncClient:
        """惰性创建 / 复用异步 httpx 客户端。"""
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=self._headers,
                timeout=_DEFAULT_TIMEOUT,
            )
        return self._async_client

    async def _request_async(
        self,
        method: str,
        endpoint: str,
        params: dict | None = None,
        *,
        use_cache: bool = True,
    ) -> dict[str, Any]:
        """发送异步 HTTP 请求并返回 JSON 数据。"""
        cache_key = self._make_cache_key(method, endpoint, params)
        if use_cache:
            cached = self._cache_get(cache_key)
            if cached is not None:
                return cached

        client = await self._get_async_client()
        try:
            response = await client.request(method, endpoint, params=params)
        except httpx.ConnectError as exc:
            raise ConnectionError(f"无法连接到平台 ({self.base_url}): {exc}") from exc
        except httpx.TimeoutException as exc:
            raise ConnectionError(f"连接平台超时: {exc}") from exc
        except httpx.HTTPError as exc:
            raise ConnectionError(f"网络请求异常: {exc}") from exc

        self._raise_for_status(response, endpoint)
        data = response.json()
        if use_cache:
            self._cache_set(cache_key, data)
        return data

    async def get_agent_config(self, name: str) -> dict[str, Any]:
        """获取指定 agent 的完整配置（含已解析的 skills 和 mcps）。"""
        return await self._request_async(
            "GET", f"/api/v1/agents/by-name/{name}/config"
        )

    async def get_skill(
        self, name: str, version: str | None = None
    ) -> dict[str, Any]:
        """获取指定 skill 的完整信息。

        Parameters
        ----------
        name:
            skill 名称。
        version:
            可选版本号，不传则返回最新版本。
        """
        params = {"version": version} if version else None
        return await self._request_async(
            "GET", f"/api/v1/skills/by-name/{name}", params=params
        )

    async def get_skill_metadata(self, name: str) -> dict[str, Any]:
        """渐进式加载：仅获取 skill 的元数据（不含 body 正文）。

        适用于列表展示或预加载场景，可显著减少传输量。
        """
        return await self._request_async(
            "GET", f"/api/v1/skills/by-name/{name}/metadata"
        )

    async def list_skill_attachments(self, skill_id: str) -> list[dict[str, Any]]:
        """列出指定 Skill 的所有附件元信息。

        Parameters
        ----------
        skill_id:
            Skill 的 UUID。

        Returns
        -------
        list[dict]
            附件元信息列表，每项包含 name、size、content_type、uploaded_at。
        """
        data = await self._request_async(
            "GET", f"/api/v1/skills/{skill_id}/attachments", use_cache=False
        )
        return data.get("attachments", [])

    async def download_skill_attachment(
        self, skill_id: str, filename: str, save_dir: str | None = None
    ) -> bytes:
        """下载指定 Skill 的一个附件文件。

        Parameters
        ----------
        skill_id:
            Skill 的 UUID。
        filename:
            附件文件名。
        save_dir:
            如果提供，将文件保存到该目录下并返回文件路径（str）；
            如果为 None，仅返回文件内容的 bytes。

        Returns
        -------
        bytes | str
            文件内容 bytes，或保存后的文件路径。
        """
        from pathlib import Path
        from urllib.parse import quote

        client = await self._get_async_client()
        endpoint = f"/api/v1/skills/{skill_id}/attachments/{quote(filename)}"
        response = await client.get(endpoint)

        if response.status_code == 404:
            raise NotFoundError(f"附件未找到: {filename}", status_code=404)
        if response.status_code >= 400:
            raise PlatformError(
                f"下载附件失败 (HTTP {response.status_code})",
                status_code=response.status_code,
            )

        content = response.content
        if save_dir:
            save_path = Path(save_dir)
            save_path.mkdir(parents=True, exist_ok=True)
            file_path = save_path / Path(filename).name
            file_path.write_bytes(content)
            return str(file_path)
        return content

    async def get_mcp(self, name: str) -> dict[str, Any]:
        """获取指定 MCP Server 的配置信息。"""
        return await self._request_async("GET", f"/api/v1/mcps/by-name/{name}")

    async def get_model_providers(self) -> dict[str, Any]:
        """获取按厂商分组的模型配置。

        返回格式与前端下拉框使用的 ``/api/v1/models/grouped`` 一致：
        ``{ "OpenAI": { "id": "...", "base_url": "...", "models": [...] }, ... }``
        """
        return await self._request_async("GET", "/api/v1/models/grouped")

    async def health_check(self) -> bool:
        """检查平台后端健康状态。

        Returns
        -------
        bool
            ``True`` 表示平台可用，``False`` 表示不可达。
        """
        try:
            await self._request_async("GET", "/health", use_cache=False)
            return True
        except PlatformError:
            return False

    # ------------------------------------------------------------------
    # 同步请求
    # ------------------------------------------------------------------

    def _get_sync_client(self) -> httpx.Client:
        """惰性创建 / 复用同步 httpx 客户端。"""
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(
                base_url=self.base_url,
                headers=self._headers,
                timeout=_DEFAULT_TIMEOUT,
            )
        return self._sync_client

    def _request_sync(
        self,
        method: str,
        endpoint: str,
        params: dict | None = None,
    ) -> dict[str, Any]:
        """发送同步 HTTP 请求并返回 JSON 数据。"""
        client = self._get_sync_client()
        try:
            response = client.request(method, endpoint, params=params)
        except httpx.ConnectError as exc:
            raise ConnectionError(f"无法连接到平台 ({self.base_url}): {exc}") from exc
        except httpx.TimeoutException as exc:
            raise ConnectionError(f"连接平台超时: {exc}") from exc
        except httpx.HTTPError as exc:
            raise ConnectionError(f"网络请求异常: {exc}") from exc

        self._raise_for_status(response, endpoint)
        return response.json()

    def get_sync(self, name: str) -> dict[str, Any]:
        """同步获取 agent 完整配置（便捷方法）。

        在无法使用 async/await 的场景下（如脚本、Jupyter Notebook）
        可直接调用此方法。内部使用独立的同步 HTTP 客户端。

        Examples
        --------
        >>> client = PlatformClient("http://127.0.0.1:8000", "your-api-key")
        >>> config = client.get_sync("my-agent")
        """
        cache_key = self._make_cache_key(
            "GET", f"/api/v1/agents/by-name/{name}/config", None
        )
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        data = self._request_sync(
            "GET", f"/api/v1/agents/by-name/{name}/config"
        )
        self._cache_set(cache_key, data)
        return data

    def get_model_providers_sync(self) -> dict[str, Any]:
        """同步获取按厂商分组的模型配置。"""
        cache_key = self._make_cache_key("GET", "/api/v1/models/grouped", None)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        data = self._request_sync("GET", "/api/v1/models/grouped")
        self._cache_set(cache_key, data)
        return data

    def download_skill_attachments_sync(
        self,
        skill_id: str,
        save_dir: str,
        *,
        overwrite: bool = False,
        prefer_zip: bool = True,
    ) -> list[str]:
        """同步下载指定 Skill 的全部附件到目录。

        Parameters
        ----------
        skill_id:
            Skill 的 UUID。
        save_dir:
            保存目录。
        overwrite:
            是否覆盖已存在的文件。默认 False：文件存在且内容未变时跳过。
        prefer_zip:
            是否优先使用 zip 打包下载接口。默认 True（后端一次性返回所有附件，
            保持目录结构，适合附件较多的 Skill）。

        Returns
        -------
        list[str]
            已保存的文件路径列表。
        """
        from pathlib import Path
        from urllib.parse import quote

        save_path = Path(save_dir)
        save_path.mkdir(parents=True, exist_ok=True)

        saved: list[str] = []

        if prefer_zip:
            # 优先走 zip 打包下载，保持目录结构
            client = self._get_sync_client()
            endpoint = f"/api/v1/skills/{skill_id}/attachments.zip"
            response = client.get(endpoint)
            if response.status_code == 200:
                import io
                import zipfile

                with zipfile.ZipFile(io.BytesIO(response.content)) as zf:
                    for info in zf.infolist():
                        if info.is_dir():
                            continue
                        rel_path = info.filename.replace("\\", "/").lstrip("/")
                        file_path = save_path / rel_path
                        file_path.parent.mkdir(parents=True, exist_ok=True)
                        data = zf.read(info)
                        if not overwrite and file_path.is_file() and file_path.read_bytes() == data:
                            continue
                        file_path.write_bytes(data)
                        saved.append(str(file_path))
                return saved
            # 404 则回退到逐个下载

        # 获取附件列表
        data = self._request_sync(
            "GET", f"/api/v1/skills/{skill_id}/attachments"
        )
        attachments = data.get("attachments", [])

        client = self._get_sync_client()
        for att in attachments:
            rel_path = att.get("path") or att.get("name", "")
            if not rel_path:
                continue
            endpoint = f"/api/v1/skills/{skill_id}/attachments/{quote(rel_path)}"
            response = client.get(endpoint)
            if response.status_code != 200:
                continue
            file_path = save_path / rel_path
            file_path.parent.mkdir(parents=True, exist_ok=True)
            data = response.content
            if not overwrite and file_path.is_file() and file_path.read_bytes() == data:
                continue
            file_path.write_bytes(data)
            saved.append(str(file_path))
        return saved

    # ------------------------------------------------------------------
    # 资源清理
    # ------------------------------------------------------------------

    async def aclose(self) -> None:
        """关闭异步客户端，释放连接资源。"""
        if self._async_client is not None and not self._async_client.is_closed:
            await self._async_client.aclose()
            self._async_client = None

    def close(self) -> None:
        """关闭同步客户端，释放连接资源。"""
        if self._sync_client is not None and not self._sync_client.is_closed:
            self._sync_client.close()
            self._sync_client = None

    async def __aenter__(self) -> "PlatformClient":
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.aclose()

    def __enter__(self) -> "PlatformClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
