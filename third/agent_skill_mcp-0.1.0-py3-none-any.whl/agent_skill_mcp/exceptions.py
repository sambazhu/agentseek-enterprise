"""SDK 自定义异常模块。

定义平台交互过程中可能抛出的所有异常类型，
方便业务代码进行细粒度的错误处理。
"""


class PlatformError(Exception):
    """平台错误基类。

    所有 SDK 相关异常均继承自此基类，
    业务代码可以捕获此异常来处理所有平台相关的错误。
    """

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code

    def __str__(self) -> str:
        if self.status_code is not None:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(PlatformError):
    """认证失败。

    当 API Key 无效或权限不足（HTTP 401/403）时抛出。
    """


class NotFoundError(PlatformError):
    """资源未找到。

    当请求的 agent / skill / mcp 不存在（HTTP 404）时抛出。
    """


class ConnectionError(PlatformError):
    """连接错误。

    当无法连接到平台服务（网络问题、超时等）时抛出。
    """
