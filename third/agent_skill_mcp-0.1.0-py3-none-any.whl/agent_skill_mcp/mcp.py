"""MCP Server 管理模块。

提供 ``MCPManager``，用于获取 MCP Server 配置、检查连接可用性
以及管理可用工具列表。
"""

from __future__ import annotations

from typing import Any

from .client import PlatformClient


class MCPManager:
    """MCP Server 管理器。

    负责从平台获取 MCP Server 配置，并对连接状态和工具进行管理。
    支持 stdio 和 SSE/HTTP 两种传输类型。

    Parameters
    ----------
    client:
        已配置好的 ``PlatformClient`` 实例。
    """

    def __init__(self, client: PlatformClient) -> None:
        self.client = client
        # 缓存已获取的 MCP 配置: name -> config dict
        self._configs: dict[str, dict[str, Any]] = {}
        # 已连接 MCP 的可用工具列表
        self._tools: list[dict[str, Any]] = []

    async def get_config(self, name: str) -> dict[str, Any]:
        """获取指定 MCP Server 的配置信息。

        首次获取后会缓存配置，后续调用直接返回缓存结果。

        Parameters
        ----------
        name:
            MCP Server 名称。

        Returns
        -------
        dict
            MCP Server 配置字典，包含 ``server_url``、``transport_type``、
            ``auth_type``、``auth_config``、``tools`` 等字段。
        """
        if name not in self._configs:
            config = await self.client.get_mcp(name)
            self._configs[name] = config
        return self._configs[name]

    async def connect(self, name: str) -> bool:
        """连接到指定的 MCP Server。

        根据配置的传输类型（``transport_type``）进行可用性检查：

        - **stdio**: 检查 ``server_url``（启动命令）是否存在。
        - **sse / http**: 检查 ``health_check_url`` 是否可达。

        .. note::
            当前实现做基本的配置校验和工具加载。
            实际的 MCP 协议握手可通过集成 ``mcp`` 官方 SDK 进一步扩展。

        Parameters
        ----------
        name:
            MCP Server 名称。

        Returns
        -------
        bool
            ``True`` 表示连接成功，``False`` 表示连接失败。
        """
        config = await self.get_config(name)
        transport_type = config.get("transport_type", "stdio")

        if transport_type == "stdio":
            # stdio 类型：检查启动命令是否存在
            server_url = config.get("server_url")
            if server_url:
                # 加载该 MCP 声明的工具列表
                tools = config.get("tools", [])
                self._tools.extend(tools)
                return True
            return False

        if transport_type in ("sse", "http"):
            # SSE / HTTP 类型：通过 health_check_url 检查可达性
            health_url = config.get("health_check_url")
            if health_url:
                # 实际生产中应发起健康检查请求
                tools = config.get("tools", [])
                self._tools.extend(tools)
                return True
            return False

        # 未知的传输类型
        return False

    def get_tools(self) -> list[dict[str, Any]]:
        """获取已连接 MCP Server 的可用工具列表。

        Returns
        -------
        list[dict]
            工具信息列表，每个元素包含工具名称、描述、参数 schema 等。
        """
        return self._tools

    def clear_tools(self) -> None:
        """清空已加载的工具列表。"""
        self._tools.clear()
