"""模型配置适配器。

从平台自动拉取模型厂商/模型配置，业务服务通过环境变量提供自己的模型 API Key，
SDK 自动组装为可直接传给 LangChain / LlamaIndex 等框架的配置。

环境变量命名规则（由业务服务自行设置）：
  - OPENAI_API_KEY
  - ANTHROPIC_API_KEY
  - DEEPSEEK_API_KEY
  - ZHIPU_API_KEY
  - QWEN_API_KEY
  - MOONSHOT_API_KEY
  - BAIDU_API_KEY
  - DOUBAO_API_KEY
  ...

也可通过 ``api_key_override`` 参数手动指定。
"""

from __future__ import annotations

import os
from typing import Any

from .client import PlatformClient


# 厂商名称 -> 环境变量名的映射
_PROVIDER_ENV_MAP: dict[str, str] = {
    "OpenAI": "OPENAI_API_KEY",
    "Anthropic": "ANTHROPIC_API_KEY",
    "Google": "GOOGLE_API_KEY",
    "xAI (Grok)": "XAI_API_KEY",
    "Mistral AI": "MISTRAL_API_KEY",
    "DeepSeek (深度求索)": "DEEPSEEK_API_KEY",
    "通义千问 (阿里云)": "QWEN_API_KEY",
    "智谱AI": "ZHIPU_API_KEY",
    "Moonshot (月之暗面/Kimi)": "MOONSHOT_API_KEY",
    "百度文心一言": "BAIDU_API_KEY",
    "字节豆包": "DOUBAO_API_KEY",
    "MiniMax (海螺AI)": "MINIMAX_API_KEY",
    "讯飞星火": "SPARK_API_KEY",
}


class ModelConfigAdapter:
    """模型配置适配器。

    从平台拉取模型配置，自动注入业务服务的 API Key。

    Usage::

        from agent_skill_mcp import PlatformClient, ModelConfigAdapter

        client = PlatformClient("http://127.0.0.1:8000", "your-api-key")
        adapter = ModelConfigAdapter(client)

        # 方式1: 异步，自动从平台拉取厂商列表
        config = await adapter.build("DeepSeek (深度求索)", "deepseek-chat")

        # 方式2: 手动指定 API Key（覆盖环境变量）
        config = await adapter.build("OpenAI", "gpt-4o", api_key_override="sk-xxx")

        # 方式3: 同步
        config = adapter.build_sync("智谱AI", "glm-4-flash")

        # config 可直接用于 LangChain
        # {
        #     "provider": "DeepSeek (深度求索)",
        #     "model": "deepseek-chat",
        #     "base_url": "https://api.deepseek.com/v1",
        #     "api_key": "业务服务自己的key",
        #     "max_tokens": 65536,
        # }

    Parameters
    ----------
    client:
        已配置好的 ``PlatformClient`` 实例。
    """

    def __init__(self, client: PlatformClient) -> None:
        self.client = client

    async def build(
        self,
        provider: str,
        model_id: str,
        *,
        api_key_override: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """异步构建模型配置。

        Parameters
        ----------
        provider:
            厂商名称，如 ``"DeepSeek (深度求索)"``。
        model_id:
            模型 ID，如 ``"deepseek-chat"``。
        api_key_override:
            手动指定 API Key，优先级高于环境变量。
        extra:
            额外配置参数（如 temperature、max_tokens 等），会合并到返回结果中。

        Returns
        -------
        dict
            可直接传给 LangChain / LlamaIndex 的配置字典。
        """
        providers = await self.client.get_model_providers()
        return self._build_config(providers, provider, model_id, api_key_override, extra)

    def build_sync(
        self,
        provider: str,
        model_id: str,
        *,
        api_key_override: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """同步构建模型配置。"""
        providers = self.client.get_model_providers_sync()
        return self._build_config(providers, provider, model_id, api_key_override, extra)

    def build_from_agent_config(
        self,
        agent_model_config: dict[str, Any],
        *,
        api_key_override: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """基于 AgentConfig.model_config 构建最终配置。

        适用于 ``AgentBuilder.build()`` 返回后，需要补充 API Key 的场景。

        Parameters
        ----------
        agent_model_config:
            从平台获取的 model_config（含 provider、model、api_base_url 等）。
        api_key_override:
            手动指定 API Key。
        extra:
            额外配置参数。

        Returns
        -------
        dict
            补充了 API Key 的完整配置。
        """
        provider = agent_model_config.get("provider", "")
        model_id = agent_model_config.get("model", "")
        api_key = api_key_override or self._resolve_api_key(provider)

        config = dict(agent_model_config)
        config["api_key"] = api_key
        if extra:
            config.update(extra)
        return config

    def _build_config(
        self,
        providers: dict[str, Any],
        provider: str,
        model_id: str,
        api_key_override: str | None,
        extra: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """内部方法：从 providers 数据中查找并组装配置。"""
        provider_data = providers.get(provider)
        if not provider_data:
            available = list(providers.keys())
            raise ValueError(
                f"未知厂商 '{provider}'，可用厂商: {available}"
            )

        # 查找模型
        models = provider_data.get("models", [])
        model_data = next((m for m in models if m["id"] == model_id), None)
        if not model_data:
            available_ids = [m["id"] for m in models]
            raise ValueError(
                f"厂商 '{provider}' 中未找到模型 '{model_id}'，"
                f"可用模型: {available_ids}"
            )

        # 解析 API Key
        api_key = api_key_override or self._resolve_api_key(provider)

        config: dict[str, Any] = {
            "provider": provider,
            "model": model_id,
            "model_name": model_data.get("name", model_id),
            "base_url": provider_data.get("base_url", ""),
            "api_key": api_key,
            "max_tokens": model_data.get("maxTokens", 4096),
        }

        if extra:
            config.update(extra)

        return config

    @staticmethod
    def _resolve_api_key(provider: str) -> str:
        """根据厂商名称从环境变量解析 API Key。

        匹配策略：
        1. 精确匹配（如 "DeepSeek (深度求索)"）
        2. 模糊匹配（如 provider="DeepSeek" 匹配到 key 包含 "DeepSeek" 的条目）
        """
        # 1. 精确匹配
        env_var = _PROVIDER_ENV_MAP.get(provider, "")
        if env_var:
            key = os.getenv(env_var, "")
            if key:
                return key

        # 2. 模糊匹配：provider 名称包含 map 的 key，或 map 的 key 包含 provider
        for map_key, map_env_var in _PROVIDER_ENV_MAP.items():
            if map_key.lower() in provider.lower() or provider.lower() in map_key.lower():
                key = os.getenv(map_env_var, "")
                if key:
                    return key

        raise ValueError(
            f"未找到厂商 '{provider}' 的 API Key。"
            f"请设置对应厂商的环境变量，或使用 api_key_override 参数手动传入。"
        )
