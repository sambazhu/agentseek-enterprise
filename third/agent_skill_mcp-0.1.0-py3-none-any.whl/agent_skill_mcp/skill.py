"""技能（Skill）数据模型与加载器。

提供 ``Skill`` Pydantic 数据模型和 ``SkillLoader`` 加载器，
支持完整加载和渐进式元数据加载两种模式。
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from .client import PlatformClient


class Skill(BaseModel):
    """表示从平台加载的技能。

    Attributes
    ----------
    name:
        技能名称（唯一标识）。
    version:
        技能版本号。
    description:
        技能描述。
    body:
        技能的 Markdown 正文内容。
    frontmatter:
        技能的 frontmatter 元数据（键值对）。
    category:
        技能分类。
    tags:
        技能标签列表。
    references:
        技能引用的外部资源列表。
    scripts:
        技能关联的脚本列表。
    """

    id: str = ""
    name: str
    version: str = ""
    category: str = ""
    tags: list[str] = Field(default_factory=list)
    description: str = ""
    frontmatter: dict[str, Any] = Field(default_factory=dict)
    body: str = ""
    references: list[Any] = Field(default_factory=list)
    scripts: list[Any] = Field(default_factory=list)

    def to_prompt_section(self, include_body: bool = False) -> str:
        """将技能内容渲染为可直接拼入 system_prompt 的 Markdown 片段。

        Parameters
        ----------
        include_body:
            是否包含完整 body 正文。默认 False，只拼描述（节省 token）。

        格式（include_body=False）::

            ## Skill: {name}
            {description}

        格式（include_body=True）::

            ## Skill: {name}
            {description}

            {body}
        """
        desc = self.description or ""
        if include_body:
            body = self.body or ""
            return f"## Skill: {self.name}\n{desc}\n\n{body}\n"
        return f"## Skill: {self.name}\n{desc}\n"


class SkillLoader:
    """技能加载器，封装从平台获取技能的逻辑。

    Parameters
    ----------
    client:
        已配置好的 ``PlatformClient`` 实例。
    """

    def __init__(self, client: PlatformClient) -> None:
        self.client = client

    async def load(self, name: str, version: str | None = None) -> Skill:
        """完整加载指定技能（含正文 body）。

        Parameters
        ----------
        name:
            技能名称。
        version:
            可选版本号。

        Returns
        -------
        Skill
            已加载的技能对象。
        """
        data = await self.client.get_skill(name, version=version)
        return Skill(**data)

    async def load_metadata(self, name: str) -> dict[str, Any]:
        """渐进式加载：仅获取技能元数据（不含 body 正文）。

        适用于列表预览、搜索等只需元数据的场景，可减少网络传输量。

        Parameters
        ----------
        name:
            技能名称。

        Returns
        -------
        dict
            技能的元数据字典。
        """
        return await self.client.get_skill_metadata(name)

    async def load_many(self, names: list[str]) -> list[Skill]:
        """批量加载多个技能。

        Parameters
        ----------
        names:
            技能名称列表。

        Returns
        -------
        list[Skill]
            已加载的技能对象列表，顺序与输入一致。
        """
        import asyncio

        tasks = [self.load(name) for name in names]
        return await asyncio.gather(*tasks)

    async def list_attachments(self, skill_id: str) -> list[dict[str, Any]]:
        """列出指定 Skill 的所有附件。

        Parameters
        ----------
        skill_id:
            Skill 的 UUID。

        Returns
        -------
        list[dict]
            附件元信息列表。
        """
        return await self.client.list_skill_attachments(skill_id)

    async def download_attachment(
        self, skill_id: str, filename: str, save_dir: str | None = None
    ) -> bytes | str:
        """下载指定 Skill 的一个附件。

        Parameters
        ----------
        skill_id:
            Skill 的 UUID。
        filename:
            附件文件名。
        save_dir:
            保存目录。传入则保存到磁盘并返回路径，不传则返回 bytes。

        Returns
        -------
        bytes | str
            文件内容或保存路径。
        """
        return await self.client.download_skill_attachment(
            skill_id, filename, save_dir=save_dir
        )

    async def download_all_attachments(
        self,
        skill_id: str,
        save_dir: str,
        *,
        overwrite: bool = False,
        prefer_zip: bool = True,
    ) -> list[str]:
        """下载指定 Skill 的全部附件到目录。

        Parameters
        ----------
        skill_id:
            Skill 的 UUID。
        save_dir:
            保存目录。
        overwrite:
            是否覆盖已存在文件。默认 False（内容一致时跳过）。
        prefer_zip:
            是否优先使用 zip 打包下载接口。默认 True。

        Returns
        -------
        list[str]
            已保存的文件路径列表。
        """
        from pathlib import Path

        save_path = Path(save_dir)
        save_path.mkdir(parents=True, exist_ok=True)

        if prefer_zip:
            client = await self.client._get_async_client()
            endpoint = f"/api/v1/skills/{skill_id}/attachments.zip"
            response = await client.get(endpoint)
            if response.status_code == 200:
                import io
                import zipfile

                saved: list[str] = []
                with zipfile.ZipFile(io.BytesIO(response.content)) as zf:
                    for info in zf.infolist():
                        if info.is_dir():
                            continue
                        rel_path = info.filename.replace("\\", "/").lstrip("/")
                        file_path = save_path / rel_path
                        file_path.parent.mkdir(parents=True, exist_ok=True)
                        data = zf.read(info)
                        if not overwrite and file_path.is_file() and file_path.read_bytes() == data:
                            continue
                        file_path.write_bytes(data)
                        saved.append(str(file_path))
                return saved

        # 回退：逐个下载
        attachments = await self.list_attachments(skill_id)
        import asyncio

        tasks = [
            self.download_attachment(skill_id, att.get("path") or att["name"], save_dir=save_dir)
            for att in attachments
        ]
        return await asyncio.gather(*tasks)

    async def load_to_dir(
        self,
        name: str,
        target_dir: str,
        *,
        include_attachments: bool = True,
        overwrite: bool = False,
        version: str | None = None,
    ) -> dict[str, Any]:
        """一键加载 Skill 并落地为本地目录（body → SKILL.md + 附件平铺）。

        将 skill 的 Markdown 正文写成 ``{target_dir}/SKILL.md``，
        并把所有附件下载到同一目录下（平铺，不建子目录）。

        Parameters
        ----------
        name:
            技能名称。
        target_dir:
            目标目录，不存在会自动创建。
        include_attachments:
            是否同时下载附件，默认 True。
        overwrite:
            是否覆盖已存在的 SKILL.md / 附件。默认 False（内容一致时跳过）。
        version:
            可选版本号。

        Returns
        -------
        dict
            结果摘要：{"skill_md": ..., "attachments": [...], "skill": Skill}
        """
        from pathlib import Path

        skill = await self.load(name, version=version)

        out_dir = Path(target_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        # 写 SKILL.md
        skill_md_path = out_dir / "SKILL.md"
        content = skill.body or ""
        # 如果有 frontmatter，还原 YAML 头部
        if skill.frontmatter:
            import json

            fm_lines = ["---"]
            for k, v in skill.frontmatter.items():
                if isinstance(v, str):
                    fm_lines.append(f"{k}: {v}")
                else:
                    fm_lines.append(f"{k}: {json.dumps(v, ensure_ascii=False)}")
            fm_lines.append("---\n")
            content = "\n".join(fm_lines) + content
        if not overwrite and skill_md_path.is_file() and skill_md_path.read_text(encoding="utf-8") == content:
            pass  # 一致则跳过
        else:
            skill_md_path.write_text(content, encoding="utf-8")

        # 下载附件
        saved_files = []
        if include_attachments and skill.id:
            saved_files = await self.download_all_attachments(
                skill.id, str(out_dir), overwrite=overwrite, prefer_zip=True
            )
            # download_all_attachments 返回的是文件路径列表

        return {
            "skill_md": str(skill_md_path),
            "attachments": saved_files,
            "skill": skill,
        }
